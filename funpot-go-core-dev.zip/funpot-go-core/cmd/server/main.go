package main

import (
	"context"
	"database/sql"
	"fmt"
	"os"
	"time"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"

	"github.com/funpot/funpot-go-core/internal/app"
	"github.com/funpot/funpot-go-core/internal/auth"
	"github.com/funpot/funpot-go-core/internal/config"
	"github.com/funpot/funpot-go-core/internal/events"
	"github.com/funpot/funpot-go-core/internal/games"
	"github.com/funpot/funpot-go-core/internal/media"
	"github.com/funpot/funpot-go-core/internal/payments"
	"github.com/funpot/funpot-go-core/internal/referrals"
	"github.com/funpot/funpot-go-core/internal/streamers"
	"github.com/funpot/funpot-go-core/internal/users"
	"github.com/funpot/funpot-go-core/internal/votes"
	"github.com/funpot/funpot-go-core/internal/wallet"
	dbpkg "github.com/funpot/funpot-go-core/pkg/database"
	"github.com/funpot/funpot-go-core/pkg/telemetry"
)

func main() {
	ctx := context.Background()

	cfg, err := config.Load()
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to load config: %v\n", err)
		os.Exit(1)
	}

	logger, err := newLogger(cfg.Logging.Level)
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to create logger: %v\n", err)
		os.Exit(1)
	}
	defer logger.Sync() //nolint:errcheck

	telemetryProvider, err := telemetry.Setup(logger, cfg.Telemetry.ServiceName, cfg.Environment, cfg.Telemetry.MetricsEnabled)
	if err != nil {
		logger.Fatal("failed to setup telemetry", zap.Error(err))
	}
	defer func() {
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err := telemetryProvider.Shutdown(shutdownCtx); err != nil {
			logger.Error("telemetry shutdown failed", zap.Error(err))
		}
	}()

	if err := telemetry.InitSentry(cfg.Sentry, logger); err != nil {
		logger.Fatal("failed to initialize sentry", zap.Error(err))
	}
	defer telemetry.FlushSentry(2 * time.Second)

	var (
		db       *sql.DB
		userRepo users.Repository
	)

	if cfg.Database.DSN() != "" {
		db, err = dbpkg.OpenPostgres(dbpkg.PostgresSettings{
			DSN:             cfg.Database.DSN(),
			MaxOpenConns:    cfg.Database.MaxOpenConns,
			MaxIdleConns:    cfg.Database.MaxIdleConns,
			ConnMaxIdleTime: cfg.Database.ConnMaxIdleTime,
			ConnMaxLifetime: cfg.Database.ConnMaxLifetime,
		})
		if err != nil {
			logger.Fatal("failed to connect to postgres", zap.Error(err))
		}
		defer func() {
			if err := db.Close(); err != nil {
				logger.Error("failed to close database", zap.Error(err))
			}
		}()

		userRepo = users.NewPostgresRepository(db)
	} else {
		logger.Warn("database connection parameters not provided; using in-memory users repository")
		userRepo = users.NewInMemoryRepository()
	}

	userService := users.NewService(userRepo)

	var (
		streamerService  *streamers.Service
		gamesService     *games.Service
		eventsService    *events.Service
		votesService     *votes.Service
		walletService    *wallet.Service
		paymentsService  *payments.Service
		referralsService *referrals.Service
		mediaService     *media.Service
	)
	if db != nil {
		streamerService = streamers.NewService(db)
		gamesService = games.NewService(db)
		eventsService = events.NewService(db)
		votesService = votes.NewService(db)
		walletService = wallet.NewService(db)
		paymentsService = payments.NewService(db)
		referralsService = referrals.NewService(db)
		mediaService = media.NewService(db)
	}

	authService, err := auth.NewService(logger, cfg.Auth, userService)
	if err != nil {
		logger.Fatal("failed to create auth service", zap.Error(err))
	}

	readyFn := func() bool {
		if db == nil {
			return true
		}

		pingCtx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()

		return db.PingContext(pingCtx) == nil
	}

	handler := app.NewHandler(
		logger,
		readyFn,
		telemetryProvider.MetricsHandler(),
		authService,
		userService,
		cfg.Features.Flags,
		streamerService,
		gamesService,
		eventsService,
		votesService,
		walletService,
		paymentsService,
		referralsService,
		mediaService,
	)

	application, err := app.New(cfg, logger, handler)
	if err != nil {
		logger.Fatal("failed to create app", zap.Error(err))
	}

	if err := application.Run(ctx); err != nil {
		logger.Fatal("application exited with error", zap.Error(err))
	}
}

func newLogger(level string) (*zap.Logger, error) {
	cfg := zap.NewProductionConfig()
	if level != "" {
		if err := cfg.Level.UnmarshalText([]byte(level)); err != nil {
			return nil, err
		}
	}
	cfg.EncoderConfig.TimeKey = "timestamp"
	cfg.EncoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder
	return cfg.Build()
}
